# kOA — Revue documentaire privée des 49 applications

Ouvre `INDEX.html` dans un navigateur. Aucune connexion réseau n’est nécessaire, sauf si tu cliques volontairement sur un lien GitHub historique.

- `REVUE-DES-PREUVES-49.md` : 49 fiches expliquées.
- `data/matrix-245.csv` : les 245 dossiers analysés, ouvrables dans Excel.
- `data/review-49.json` : format machine exploitable pour un futur assistant de préqualification.
- `sources/engineering/` : copies datées des 12 Engineering Profiles fournis et leurs métriques/provenances.
- `sources/architecture/` : documents ciblés du snapshot de gouvernance, dont le rapport Konnaxion-Orgo E2E du 21 septembre 2026.
- `sources/diagnostics/` : résumés des audits par dépôt, sans les chemins privés complets.
- `sources/diagnostic-docs/` : documents datés des outils KonnaxionDiag et LevelUpDiag-Orgo présentant des tests **rapportés**, non les logs bruts.

Ce dossier ne remplace pas les sources originales. Les deux audits locaux `audit.json` et `audit(1).json` ont été recoupés ; les fiches utilisent le plus récent, car Kristal-Manager y possède un SHA et un nombre de fichiers différents. Les ZIP de diagnostic de code ne sont PAS des journaux d’exécution et ne sont pas recopiés intégralement. Les références à ces ZIP correspondent aux fichiers transmis dans la conversation.

L’archive de campagne produite sur Windows dans `%LOCALAPPDATA%` ne fait pas partie des documents fournis ici : les évaluations qui y sont enregistrées ne sont pas connues de cette revue.

Aucune des 245 qualifications n’est automatiquement acceptée ni importée. Les preuves restent datées et de portée limitée.
