# Revue des preuves kOA — 49 dépôts × 5 jalons (245 dossiers)

**Nature :** revue documentaire des ZIP/logs déjà transmis ; aucun test exécuté, aucun dépôt modifié, aucune certification accordée.
**Dates des sources :** 21 septembre–30 octobre 2026. Le registre privé de campagnes créé sur ton Windows n’a pas été téléchargé ici.
**Règle :** une mesure, un scan, une exécution CI ou un contrat n’atteste pas automatiquement la maturité entière d’une application.

## Résultats vérifiés

- Inventaire Kristal : **49/49**; associations explicites **14**, propositions **23**, autres **12**.
- Audit local : **47/49** avec SHA historique; ce SHA ne certifie pas le snapshot d’ingénierie. Deux observations distinctes (`audit.json` 18:56 UTC et `audit(1).json` 20:42 UTC), dont la plus récente est utilisée dans les fiches.
- Engineering Profiles dans l’inventaire : **12/49** (13e supplémentaire, hors 49).
- **4 dossiers jalon/application** (Konnaxion et Orgo, testé et intégré) disposent d’un compte rendu E2E local daté et précis; ce n’est pas 4 certifications enregistrées.
- **3 outils** possèdent des résultats de tests rapportés dans des documents de tournée (Konnaxion-Capsule-Manager : 40, KonnaxionDiag : 71, LevelUpDiag-Orgo : 95), sans logs de run bruts et SHA concordants dans ce lot.
- Aucun dossier de preuve de production suffisant avec environnement et version exacte dans les documents analysés.
- Pour Kristal-Manager, le SHA et le nombre de fichiers ont changé entre les deux audits locaux : la revue retient l’audit de 20:42 UTC. Les autres dépôts montrent le même SHA dans ces deux collectes.
- Résultats CI observés uniquement sur une partie des dépôts (15 métadonnées disponibles dans l’ancien audit distant) ; sans logs JUnit/recette et portée, aucun verdict global.

## Exemple substantiel : Konnaxion ↔ Orgo

Le rapport `docs/status/2026-09-21-konnaxion-orgo-ik-e2e-qualification.md` contient un résultat **QUALIFIED — local integrated runtime** pour les contrats `governance.decision.execute/1.0.0` et `accountability.impact.publish/1.0.0`, avec replay idempotent et conflit divergent rejeté.
La portée est le runtime intégré local et ces deux profils. **Ce document ne fournit pas les SHA individuels des deux clones participants**, et n’atteste pas la production. Il doit être validé dans le registre avec cette portée avant de déplacer une case du compteur.

## Distinguer les sources

| Source | Ce qu’elle établit | Ce qu’elle ne démontre pas |
|---|---|---|
| Diagnostic Kristal | 49 identités de dépôts, 14 associations explicites, 23 propositions, relations sémantiques | Fonctionnement ou qualité du code, tests ou intégration réelle |
| Audit local `audit(1).json` | 47 observations, SHA locaux, configurations CI et motifs heuristiques | Absence de vulnérabilité, réussite de tests, production |
| Audit GitHub `audit(2).json` | Métadonnées CI accessibles historiquement, dernier run et commit observés | Résultats de suite de tests et couverture des 49 |
| Profils RepoSurveyor | 12 mesures de code snapshot et déclarations de tests | Exécution/qualification de ces tests, association prouvée au SHA Git |
| Snapshots de code des outils diagnostic | Code/tests présents pour les outils de diagnostic | Le journal de leur exécution réelle |
| Référentiel de gouvernance kOA | Contrats, responsabilité et quelques résultats E2E locaux datés | Certification universelle d’application ou de production |

## Fiches par dépôt

### Akor

- **Dépôt :** `Rejean-McCormick/Akor`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `cc86fccc9dd9a73aec937486a7e3cfbc917d0fdb` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:akor | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 115 fichiers énumérés, 40 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Le dernier workflow GitHub observé indique « failure ». Cela ne suffit pas pour conclure sur la qualification fonctionnelle. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 5 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Arketype

- **Dépôt :** `Rejean-McCormick/Arketype`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `091d31659767e702440ade23cf0c9e2470d0035b` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:arketype | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 819 fichiers énumérés, 329 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Le dernier workflow GitHub observé indique « failure ». Cela ne suffit pas pour conclure sur la qualification fonctionnelle. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 3 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Daat

- **Dépôt :** `Rejean-McCormick/Daat`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `24d288b040d345405c508eb650d40a6c8856cf2a` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 134 fichiers actifs, 18 fichiers de source de production, 885 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 7 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Daat/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/knowledge-projection.md`

### Ekole

- **Dépôt :** `Rejean-McCormick/Ekole`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `74f16e23089f0f46c23777bbaed92e2613d2939e` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Audit LOCAL_OBSERVE : 231 fichiers énumérés, 143 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/skope-ekole/index.md`

### Ekole-Pastorale

- **Dépôt :** `Rejean-McCormick/Ekole-Pastorale`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `0ca3e9ad06de7a41940c3459cdb8183e3cf2643a` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:ekole-pastorale | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 1595 fichiers énumérés, 813 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 4 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### EncyKlopedia

- **Dépôt :** `Rejean-McCormick/EncyKlopedia`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `25d970c45c358c9de2ade33b8703db225c7f4676` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Audit LOCAL_OBSERVE : 22 fichiers énumérés, 10 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | GitHub API historique: dernier workflow sur branche par défaut conclu success au commit HEAD observé. | Exécution CI observée réussie au SHA |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/knowledge-projection.md`

### HomePage-initkoa.org

- **Dépôt :** `Rejean-McCormick/HomePage-initkoa.org`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `3b952d1da199b8ff827141022576775e8c8c9f34` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 648 fichiers énumérés, 220 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### initkoa-docs

- **Dépôt :** `Rejean-McCormick/initkoa-docs`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `07526773197cf9d7c54eed54988fa56007decbe3` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 107 fichiers énumérés, 4 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Succès de workflow observé, mais le SHA du run diffère du HEAD observé. | Exécution CI historique réussie (autre SHA) |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Interaction-Kernel

- **Dépôt :** `Rejean-McCormick/Interaction-Kernel`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `1d0598456fe8203625f9831ec00c32225422631d` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 165 fichiers actifs, 30 fichiers de source de production, 1206 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 17 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Interaction-Kernel/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/interaction-kernel/status.md`

### kOA-Digital-Ecosystem

- **Dépôt :** `Rejean-McCormick/kOA-Digital-Ecosystem`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `a1bcf3ae717dcc5fd39a4f499b8d109d58ff55ba` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Audit LOCAL_OBSERVE : 218 fichiers énumérés, 25 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/contract-map.md`

### kOA-Linux-Koali

- **Dépôt :** `Rejean-McCormick/kOA-Linux-Koali`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `8f70441f18a259023a4c0a643bff82d731634cf5` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 1649 fichiers actifs, 524 fichiers de source de production, 111068 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 219 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/kOA-Linux-Koali/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/tandem-vps-capsule-agent/evidence-ledger.md`

### Koali-Control-Panel

- **Dépôt :** `Rejean-McCormick/Koali-Control-Panel`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `7b476c20de7ac71332762a6e4e23cdde98f29148` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:koali-control-panel ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 60 fichiers énumérés, 31 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | GitHub API historique: dernier workflow sur branche par défaut conclu success au commit HEAD observé. | Exécution CI observée réussie au SHA |
| Intégré entre systèmes | 9 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Koali-Scenario-Mosaic

- **Dépôt :** `Rejean-McCormick/Koali-Scenario-Mosaic`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `4ac4e787ef01295c9100c73d8b5bbf9a19d9ef03` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:scenario-mosaic ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 332 fichiers énumérés, 51 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | GitHub API historique: dernier workflow sur branche par défaut conclu success au commit HEAD observé. | Exécution CI observée réussie au SHA |
| Intégré entre systèmes | 16 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Koali-Spaces

- **Dépôt :** `Rejean-McCormick/Koali-Spaces`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `74e321432844bcf102f6671e6f5449afae8acf08` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 363 fichiers actifs, 112 fichiers de source de production, 7980 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 22 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Koali-Spaces/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/koali-spaces/index.md`

### Kompiler

- **Dépôt :** `Rejean-McCormick/Kompiler`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `cf4836ccf2741b609c562254d09ba47d7e9a6187` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:kompiler ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 224 fichiers énumérés, 147 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 10 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kompose

- **Dépôt :** `Rejean-McCormick/Kompose`
- **Profil RepoSurveyor :** non fourni; **audit local :** non observé; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** non observé (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:kompose | Lien de composant déclaré |
| Implémenté | Aucune mesure de code spécifique exploitable dans les archives passées en revue. | Non établi dans les archives disponibles |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 3 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Konductor

- **Dépôt :** `Rejean-McCormick/Konductor`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `f69b57d0208973ee7508490d0dc221986d653b9c` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:konductor ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 14 fichiers énumérés, 7 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 10 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Konfid

- **Dépôt :** `Rejean-McCormick/Konfid`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `e3d96da8e880815dc6e6d75e8662f2ab6e871bfc` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:konfid ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Snapshot RepoSurveyor: 99 fichiers actifs, 37 fichiers de source de production, 5069 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 10 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 11 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Konfid/ENGINEERING_PROFILE.md`

### Konnaxion

- **Dépôt :** `Rejean-McCormick/Konnaxion`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `59601fb9cd74fb8f9d8037ed97a0441f285242a1` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 1166 fichiers actifs, 796 fichiers de source de production, 109361 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | Rapport daté du 2026-09-21: E2E local PASS pour deux profils Konnaxion↔Orgo, avec rejeu idempotent et conflit divergent rejeté. | Compte rendu de qualification locale ciblée |
| Intégré entre systèmes | Frontière Konnaxion ↔ Orgo démontrée localement, deux contrats/version, rejeu et mutation locale aux propriétaires. | Compte rendu E2E local daté |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Konnaxion/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/status/2026-09-21-konnaxion-orgo-ik-e2e-qualification.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/orgo-konnaxion/index.md`

### Konnaxion-Capsule-Manager

- **Dépôt :** `Rejean-McCormick/Konnaxion-Capsule-Manager`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `a137f3c1ab5e7a79887074560b11a2a6b0a70518` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 366 fichiers actifs, 192 fichiers de source de production, 83736 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 40 tests locaux annoncés dans un document de tournée ou un registre de preuves propriétaire; le rapport d’exécution brut avec commit n’est pas fourni ici. | Tests locaux rapportés (journal brut non fourni) |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Konnaxion-Capsule-Manager/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/tandem-vps-capsule-agent/evidence-ledger.md`

### Konnaxion-Worlds

- **Dépôt :** `Rejean-McCormick/Konnaxion-Worlds`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `db72efc2372f1c7eb048e28c4f799a99b42237b6` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:konnaxion-worlds ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Snapshot RepoSurveyor: 507 fichiers actifs, 67 fichiers de source de production, 8582 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 15 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 8 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Konnaxion-Worlds/ENGINEERING_PROFILE.md`

### KonnaxionDiag

- **Dépôt :** `Rejean-McCormick/KonnaxionDiag`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `6d058a178fbaab7dd5e11cdd4310a22295021b65` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Archive de code de l’outil diagnostic fournie, sans preuve de sa couverture fonctionnelle complète. | Snapshot de l’outil disponible |
| Testé / qualifié | 71 tests locaux annoncés dans un document de tournée ou un registre de preuves propriétaire; le rapport d’exécution brut avec commit n’est pas fourni ici. | Tests locaux rapportés (journal brut non fourni) |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/tandem-vps-capsule-agent/evidence-ledger.md`, `KonnaxionDiag_Code_snapshot(1).zip`

### Konstellation

- **Dépôt :** `Rejean-McCormick/Konstellation`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `9d4f7e74ed87b5a4c8d284dad891029d834911e4` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:konstellation ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 293 fichiers énumérés, 172 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 13 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Konstellation-Light

- **Dépôt :** `Rejean-McCormick/Konstellation-Light`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `b29e9306fd809812f65af178e0ea28676b2bda87` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 82 fichiers énumérés, 57 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Konstellation-Publisher

- **Dépôt :** `Rejean-McCormick/Konstellation-Publisher`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `35528f27d6e1445f641e0e677dbe4507a5eacbf4` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:konstellation-publisher ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 34 fichiers énumérés, 16 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 7 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kontainer

- **Dépôt :** `Rejean-McCormick/Kontainer`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `0d9c208942ff9bd23fa7c601e1a455949f03fe67` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 66 fichiers énumérés, 36 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kontexte

- **Dépôt :** `Rejean-McCormick/Kontexte`
- **Profil RepoSurveyor :** non fourni; **audit local :** non observé; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** non observé (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:kontexte | Lien de composant déclaré |
| Implémenté | Aucune mesure de code spécifique exploitable dans les archives passées en revue. | Non établi dans les archives disponibles |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 3 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kristal-Authoring-Kit

- **Dépôt :** `Rejean-McCormick/Kristal-Authoring-Kit`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `c02d6d6afa2c00da1863047626c31bbf766876dc` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:kristal-authoring-kit | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 274 fichiers énumérés, 129 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 4 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kristal-Framework

- **Dépôt :** `Rejean-McCormick/Kristal-Framework`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `68ba4c8ca9fff5f410d005fc6142b8c018716eb7` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Snapshot RepoSurveyor: 619 fichiers actifs, 58 fichiers de source de production, 8288 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 14 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Kristal-Framework/ENGINEERING_PROFILE.md`

### Kristal-Integration-Pack

- **Dépôt :** `Rejean-McCormick/Kristal-Integration-Pack`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `b7e08f38460917f6e23df59151b1a8b8e447b4f7` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 49 fichiers énumérés, 30 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Kristal-Manager

- **Dépôt :** `Rejean-McCormick/Kristal-Manager`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `72fb61f98397b088a8c62d7c753f237ea0f3fb72` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 787 fichiers énumérés, 696 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### kristal-public

- **Dépôt :** `Rejean-McCormick/kristal-public`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `3ecf877c7fb47579d5284e5ba57f7459d6232059` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 26 fichiers énumérés, 14 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### KristalDiag

- **Dépôt :** `Rejean-McCormick/KristalDiag`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `9af3637636606583ef850a9bffe56f92b3a526fc` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:kristaldiag | Lien de composant déclaré |
| Implémenté | Archive de code de l’outil diagnostic fournie, sans preuve de sa couverture fonctionnelle complète. | Snapshot de l’outil disponible |
| Testé / qualifié | Le snapshot contient le code de l’outil diagnostic, pas de journal de test horodaté vérifié. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 10 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `KristalDiag_Code_snapshot(1).zip`

### LevelUpDiag-kOA-Linux

- **Dépôt :** `Rejean-McCormick/LevelUpDiag-kOA-Linux`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `5a7d7c51dbbb9591c153323a6f7ab3248c36f2f5` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:levelupdiag-koa-linux | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 79 fichiers énumérés, 60 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 6 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### LevelUpDiag-Orgo

- **Dépôt :** `Rejean-McCormick/LevelUpDiag-Orgo`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `79d495e637838784a1e137a7cf83722354f020f2` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:levelupdiag-orgo | Lien de composant déclaré |
| Implémenté | Archive de code de l’outil diagnostic fournie, sans preuve de sa couverture fonctionnelle complète. | Snapshot de l’outil disponible |
| Testé / qualifié | 95 tests locaux annoncés dans un document de tournée ou un registre de preuves propriétaire; le rapport d’exécution brut avec commit n’est pas fourni ici. | Tests locaux rapportés (journal brut non fourni) |
| Intégré entre systèmes | 6 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `LevelUpDiag-Orgo_Code_snapshot(1).zip`

### LevelUpDiag_SemantiK-Architect

- **Dépôt :** `Rejean-McCormick/LevelUpDiag_SemantiK-Architect`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `4c8505150eae36193bc32cff587ba0860d608f2f` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:levelupdiag-semantik | Lien de composant déclaré |
| Implémenté | Archive de code de l’outil diagnostic fournie, sans preuve de sa couverture fonctionnelle complète. | Snapshot de l’outil disponible |
| Testé / qualifié | Le snapshot contient le code de l’outil diagnostic, pas de journal de test horodaté vérifié. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 6 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `LevelUpDiag_SemantiK_Architect_Code_snapshot.zip`

### Mediatheque

- **Dépôt :** `Rejean-McCormick/Mediatheque`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `21e8d732e6690ab15ced87179eb5b152386fe716` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 421 fichiers énumérés, 313 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Mediatheque-blank

- **Dépôt :** `Rejean-McCormick/Mediatheque-blank`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `a853781bba11179da00bd16735ff4e13ef9499f4` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 44 fichiers énumérés, 11 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### MediKristal

- **Dépôt :** `Rejean-McCormick/MediKristal`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `ed1ed01cc8a71c4464087c31db80bc20b9eb58e6` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:medikristal ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 128 fichiers énumérés, 74 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 8 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### MediKristal-LevelUpDiag-

- **Dépôt :** `Rejean-McCormick/MediKristal-LevelUpDiag-`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `ce1c0dead57361ef21f9e3fcd8043711124ba41d` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:levelupdiag-medikristal | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 87 fichiers énumérés, 68 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 6 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Orgo

- **Dépôt :** `Rejean-McCormick/Orgo`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `381ab137d087794ffcb381532c7d2eabcdd60bb5` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 363 fichiers actifs, 138 fichiers de source de production, 21233 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | Rapport daté du 2026-09-21: E2E local PASS pour deux profils Konnaxion↔Orgo, avec rejeu idempotent et conflit divergent rejeté. | Compte rendu de qualification locale ciblée |
| Intégré entre systèmes | Frontière Konnaxion ↔ Orgo démontrée localement, deux contrats/version, rejeu et mutation locale aux propriétaires. | Compte rendu E2E local daté |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Orgo/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`, `sources/architecture/docs/status/2026-09-21-konnaxion-orgo-ik-e2e-qualification.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/orgo-konnaxion/index.md`

### Orgo-Worlds

- **Dépôt :** `Rejean-McCormick/Orgo-Worlds`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `c2445db8abf78afcb647f22615ad3b9dd132bde8` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:orgo-worlds ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Snapshot RepoSurveyor: 195 fichiers actifs, 36 fichiers de source de production, 2934 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 12 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 8 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/Orgo-Worlds/ENGINEERING_PROFILE.md`

### SemantiK-Architect

- **Dépôt :** `Rejean-McCormick/SemantiK-Architect`
- **Profil RepoSurveyor :** oui; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `74b07c42811dae0c68549d8554c00bc44a04298d` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Snapshot RepoSurveyor: 280 fichiers actifs, 95 fichiers de source de production, 5065 lignes non vides de code de production. | Code mesuré dans un snapshot |
| Testé / qualifié | 26 fichiers de tests dans le snapshot ; aucun test exécuté lors de cette mesure. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/engineering/SemantiK-Architect/ENGINEERING_PROFILE.md`, `sources/architecture/docs/status/current.md`

### SemantiK_Runtime_Orchestrator

- **Dépôt :** `Rejean-McCormick/SemantiK_Runtime_Orchestrator`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `4e6a4fb58af8f8dbe3acc2bdde50701b2b482b87` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Audit LOCAL_OBSERVE : 54 fichiers énumérés, 40 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`

### SenTient

- **Dépôt :** `Rejean-McCormick/SenTient`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `bdd25f26bed6a38aec33dd8bc601f74629ec555c` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:sentient ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 591 fichiers énumérés, 349 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 10 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### Skope

- **Dépôt :** `Rejean-McCormick/Skope`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `743f36d0215f794ef1fd585cccde3d54b7d39608` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Le référentiel d’architecture mentionne explicitement ce système ou sa frontière. | Documentation ciblée à examiner |
| Implémenté | Audit LOCAL_OBSERVE : 493 fichiers énumérés, 271 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Le référentiel décrit des contrats/liaisons, sans démontrer une recette E2E de cette application au commit ciblé. | Frontières d’intégration documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`, `sources/architecture/docs/2-Technical-Reference/40-integration/skope-ekole/index.md`

### Spek

- **Dépôt :** `Rejean-McCormick/Spek`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 1; **candidats :** 0.
- **Commit audit historique :** `ddeafc2f13fac98f850ace8300ee36080f63159a` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Lien dépôt→composant explicite dans Kristal: koa:spek | Lien de composant déclaré |
| Implémenté | Audit LOCAL_OBSERVE : 153 fichiers énumérés, 67 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 3 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

### UCKK-Assets

- **Dépôt :** `Rejean-McCormick/UCKK-Assets`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 0.
- **Commit audit historique :** `d88edc844e1ac0be63a447c56060ebaaa4586e1a` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Référencement du dépôt dans Kristal; aucune association explicite ou candidate dans ce diagnostic. | Non établi dans les archives disponibles |
| Implémenté | Audit LOCAL_OBSERVE : 176 fichiers énumérés, 7 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | Aucune preuve d’intégration exécutable retrouvée dans les archives disponibles. | Non établi dans les archives disponibles |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** `sources/architecture/docs/status/current.md`

### UCKK-Ops-Console

- **Dépôt :** `Rejean-McCormick/UCKK-Ops-Console`
- **Profil RepoSurveyor :** non fourni; **audit local :** oui; **relations explicites :** 0; **candidats :** 1.
- **Commit audit historique :** `84e85c41f42817bc68ff596bf8de6cd2c76c77a3` (ne prouve pas la provenance des profils)

| Jalon | Ce que démontrent les archives | Degré documentaire |
|---|---|---|
| Spécifié / architecturé | Candidat(s) Kristal koa:uckk-ops-console ; association non validée. | Correspondance documentaire proposée |
| Implémenté | Audit LOCAL_OBSERVE : 155 fichiers énumérés, 15 inspectés sous plafonds de recherche. | Fichiers observés dans un audit |
| Testé / qualifié | Aucun résultat de test avec portée et version reproductibles dans les archives consultées. | Non établi dans les archives disponibles |
| Intégré entre systèmes | 7 occurrences de relation(s) dans le graphe Kristal pour les composants associés/proposés. | Relations sémantiques documentées |
| Éprouvé en production | Aucune attestation de production à portée, version et environnement vérifiables parmi ces sources. | Non établi dans les archives disponibles |

**Sources utiles :** 

## Interprétation du 0/245

0/245 est le nombre de **jalons enregistrés comme « Étayé par preuve » dans la campagne locale**. Il ne reflète pas à lui seul les preuves historiques existantes dans ces archives. Cette revue ne touche pas le registre ; pour changer les compteurs futurs, chaque proposition doit être validée en précisant la portée et la version, puis figée dans une nouvelle campagne.

## Étape suivante pour incorporer dans la campagne Windows

Importer **uniquement les propositions de revue** dans un assistant de décision, **sans écrire automatiquement** dans `qualification.json`. Vérifier la correspondance SHA/snapshot pour chaque dossier, accepter les preuves E2E locales sous leur périmètre contractuel, et conserver les états `Non évalué` tant qu’une décision n’a pas été enregistrée. Le ZIP de campagne réellement produit sur le PC n’est pas fourni dans cette conversation.
